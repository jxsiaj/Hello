from model.vision_transformer import ViT2
import torch
import torch.nn as nn
import copy
# L2 norm
class Normalize(nn.Module):
    def __init__(self, power=2):
        super(Normalize, self).__init__()
        self.power = power

    def forward(self, x):
        norm = x.pow(self.power).sum(1, keepdim=True).pow(1. / self.power)
        out = x.div(norm)
        return out  

def weights_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_out')
        nn.init.constant_(m.bias, 0.0)

    elif classname.find('Conv') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_in')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)
    elif classname.find('BatchNorm') != -1:
        if m.affine:
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0.0)


def weights_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.normal_(m.weight, std=0.001)
        if m.bias:
            nn.init.constant_(m.bias, 0.0)


class build_vision_transformer(nn.Module):
    def __init__(self, num_classes,cfg):
        
        super(build_vision_transformer, self).__init__()
        self.cls_token_num = cfg.MODEL.CLS_TOKEN_NUM
        self.in_planes = 768
        self.base = ViT2(img_size=[cfg.H,cfg.W],
                        stride_size=cfg.STRIDE_SIZE,
                        drop_path_rate=cfg.DROP_PATH,
                        drop_rate=cfg.DROP_OUT,
                        attn_drop_rate=cfg.ATT_DROP_RATE,cfg=cfg)

        self.base.load_param(cfg.PRETRAIN_PATH)
        print('Loading pretrained ImageNet model......from {}'.format(cfg.PRETRAIN_PATH))
        self.gap = nn.AdaptiveAvgPool2d(1)

        self.num_classes = num_classes
        self.classifiers = nn.ModuleList([
                nn.Linear(self.in_planes, self.num_classes, bias=False)
                for _ in range(self.cls_token_num)])
        self.bottlenecks = nn.ModuleList([
            nn.BatchNorm1d(self.in_planes)
            for _ in range(self.cls_token_num)])
        for classifier, bottleneck in zip(self.classifiers, self.bottlenecks):
            classifier.apply(weights_init_classifier)
            bottleneck.bias.requires_grad_(False)
            bottleneck.apply(weights_init_kaiming)
        self.l2norm = Normalize(2)

        
    def forward(self, x):
        global_feats= self.base(x)
        feats = [bottleneck(global_feats[:, i]) for i, bottleneck in enumerate(self.bottlenecks)]
        if self.training:
            weight = None
            cls_scores = [classifier(feats[i]) for i, classifier in enumerate(self.classifiers)]
            return cls_scores, [global_feats[:, i] for i in range(global_feats.shape[1])]
        else:
            feat1 = torch.cat(feats, dim=1)
            feat = self.l2norm(feat1) 
            return feat


    def load_param(self, trained_path):
        param_dict = torch.load(trained_path)
        for i in param_dict:
            self.state_dict()[i.replace('module.', '')].copy_(param_dict[i])
        print('Loading pretrained model from {}'.format(trained_path))

    def load_param_finetune(self, model_path):
        param_dict = torch.load(model_path)
        for i in param_dict:
            self.state_dict()[i].copy_(param_dict[i])

        print('Loading pretrained model for finetuning from {}'.format(model_path))


def make_model(cfg, num_class):
    model =build_vision_transformer (num_class,cfg)
    print('===========building transformer===========')
    return model
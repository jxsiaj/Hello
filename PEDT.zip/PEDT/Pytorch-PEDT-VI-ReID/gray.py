import matplotlib.pyplot as plt
import os
import cv2
from transforms import * 
# 原始RGB图像
image_path = '/home/ljb/code/PMT-main/Pytorch-PMT-VI-ReID/image/0008_c1_0015.jpg'# 你的RGB图像数据
save_dir = "gary_image"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)
save_path = os.path.join(save_dir, "0008_c1_0015.jpg")

image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
cv2.imwrite(save_path,image)